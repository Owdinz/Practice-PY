import math

a = int(input("Enter your first number: "))
b = int(input("Enter your second number: "))

z = math.gcd(a, b)

print("The numbers {} and {} are only divisible by {}".format(a, b, z))